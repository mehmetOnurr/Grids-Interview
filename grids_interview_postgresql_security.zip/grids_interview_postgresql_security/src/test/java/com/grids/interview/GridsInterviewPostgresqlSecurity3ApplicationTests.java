package com.grids.interview;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GridsInterviewPostgresqlSecurity3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
