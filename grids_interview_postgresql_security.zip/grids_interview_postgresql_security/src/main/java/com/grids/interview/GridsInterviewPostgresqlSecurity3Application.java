package com.grids.interview;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.grids.interview.respository.UsersRepository;



@SpringBootApplication
@EnableJpaRepositories(basePackageClasses = UsersRepository.class)
public class GridsInterviewPostgresqlSecurity3Application   {


	
	public static void main(String[] args) {
		SpringApplication.run(GridsInterviewPostgresqlSecurity3Application.class, args);
	}

	

}
