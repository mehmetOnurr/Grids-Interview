package com.grids.interview.securitycontroller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.grids.interview.model.MyUserDetails;
import com.grids.interview.model.Users;
import com.grids.interview.respository.UsersRepository;

public class MyUserDetailsService  implements UserDetailsService{

	 @Autowired
	    UsersRepository usersRepository;

	    @Override
	    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
	        Optional<Users> user = usersRepository.findByUserName(userName);

	        user.orElseThrow(() -> new UsernameNotFoundException("Not found: " + userName));

	        return user.map(MyUserDetails::new).get();
	    }
}
