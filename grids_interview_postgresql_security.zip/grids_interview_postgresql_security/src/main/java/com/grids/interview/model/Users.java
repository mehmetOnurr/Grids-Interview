package com.grids.interview.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Users")
public class Users {

	    @Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    private int userid;
	    @Column(name="userName")
	    private String userName;
	   	
	    @Column(name="userPassword")
	    private String userpassword;
	    @Column(name="active")
	    private boolean active;
	    @Column(name="roles")
	    private String roles;

	    public int getId() {
	        return userid;
	    }

	    public void setId(int id) {
	        this.userid = id;
	    }

	    public String getUserName() {
	        return userName;
	    }

	    public void setUserName(String userName) {
	        this.userName = userName;
	    }

	    public String getPassword() {
	        return userpassword;
	    }

	    public void setPassword(String password) {
	        this.userpassword = password;
	    }

	    public boolean isActive() {
	        return active;
	    }

	    public void setActive(boolean active) {
	        this.active = active;
	    }

	    public String getRoles() {
	        return roles;
	    }

	    public void setRoles(String roles) {
	        this.roles = roles;
	    }
	
}
