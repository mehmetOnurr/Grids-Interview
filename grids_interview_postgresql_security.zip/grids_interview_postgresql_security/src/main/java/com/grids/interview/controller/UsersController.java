package com.grids.interview.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.grids.interview.exception.ResourceNotFoundException;

import com.grids.interview.model.Users;
import com.grids.interview.respository.UsersRepository;

@RestController
@RequestMapping("Users")
public class UsersController {
	
	@Autowired
	private UsersRepository usersRepository;
	
	@GetMapping("Users")
	public List<Users> getAllusers(){
		return this.usersRepository.findAll();
	}
	
	@GetMapping("Users/{id}")
	public ResponseEntity<Users> getEmployeeById(@PathVariable(value = "id") Integer usersId)
			throws ResourceNotFoundException {
		Users users = usersRepository.findById(usersId)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not found for this id :: " + usersId));
		return ResponseEntity.ok().body(users);
	}
	
	//save roles
		@PostMapping("Users")
		public Users createEmployee(@Valid @RequestBody Users users) {
			return usersRepository.save(users);
		}
		//update employee
		@PutMapping("Users/{id}")
		public ResponseEntity<Users> updateRoles(@PathVariable(value = "id") Integer usersId,
				@Valid @RequestBody Users userDetails) throws ResourceNotFoundException {
			Users users = usersRepository.findById(usersId)
					.orElseThrow(() -> new ResourceNotFoundException("Employee not found for this id :: " + usersId));
	    
			users.getUserName();
			users.getPassword();
			users.isActive();
			
	        
			
			final Users updatedUsers = usersRepository.save(users);
			return ResponseEntity.ok(updatedUsers);
		}
		
		@DeleteMapping("Users/{id}")
		public Map<String, Boolean> deleteEmployee(@PathVariable(value = "id") Integer usersId)
				throws ResourceNotFoundException {
			Users users = usersRepository.findById(usersId)
					.orElseThrow(() -> new ResourceNotFoundException("Employee not found for this id :: " + usersId));

			usersRepository.delete(users);
			Map<String, Boolean> response = new HashMap<>();
			response.put("deleted", Boolean.TRUE);
			return response;
		}

}
